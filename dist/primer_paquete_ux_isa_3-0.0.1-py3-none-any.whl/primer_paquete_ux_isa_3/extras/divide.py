def divide(a, b):
    if b == 0:
        print("Error: División por cero.")
        return None
    return a / b
