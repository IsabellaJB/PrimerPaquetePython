def restar(a, b):
    """Resta dos números."""
    return a - b