def sumar(a, b):
    """Suma dos números."""
    return a + b