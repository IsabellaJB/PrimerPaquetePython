from multiplica import multiplica
from divide import divide