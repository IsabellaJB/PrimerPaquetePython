def multiplicar(a, b):
    """Multiplica dos números."""
    return a * b
